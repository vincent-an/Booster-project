package fortuneCookie.booster.domain.user.entity.enums;

public enum Department {
    첨단학부, 자연계열학부, 인문사회계열학부, 자유전공학부, 임상병리학과, 방사선학과,
    안경광학과, 응급구조학과, 의료경영학과, 물리치료학과, 치위생학과, 간호학과, 의예과
}
