package fortuneCookie.booster.global.exception;

public class ImageDeleteException extends RuntimeException{
    public ImageDeleteException(String message) {
        super(message);
    }
}
