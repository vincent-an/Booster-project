package fortuneCookie.booster.domain.user.jwt;

import fortuneCookie.booster.domain.user.dto.CustomUserDetails;
import fortuneCookie.booster.domain.user.dto.LoginUserDTO;
import fortuneCookie.booster.domain.user.repository.UserRepository;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Slf4j
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;

    // 인증을 요구하지 않는 경로만 화이트리스트 (B 방식 유지)
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        String path = request.getRequestURI();
        String method = request.getMethod();

        // CORS preflight는 통과
        if ("OPTIONS".equalsIgnoreCase(method)) return true;

        // 공개 경로
        if ("/".equals(path)
                || "/booster/login".equals(path)
                || "/booster/join".equals(path)
                || "/booster/reissue".equals(path)) {
            return true;
        }

        // 게시판 조회는 GET만 공개
        if ("GET".equalsIgnoreCase(method) &&
                (path.startsWith("/booster/freeBoard")
                        || path.startsWith("/booster/promoBoard")
                        || path.startsWith("/booster/infoBoard")
                        || path.startsWith("/booster/tmiBoard")
                        || path.startsWith("/booster/generalBoard"))) {
            return true;
        }

        // 그 외는 필터 적용(= 인증 필요 경로)
        return false;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        // 1) 헤더에서 토큰 추출: Authorization(Bearer ...) 우선, 없으면 access 헤더 지원
        String token = null;

        String authHeader = request.getHeader("Authorization");
        if (authHeader != null) {
            // 보통 "Bearer <jwt>" 형식
            if (authHeader.regionMatches(true, 0, "Bearer ", 0, 7) && authHeader.length() > 7) {
                token = authHeader.substring(7).trim();
            } else {
                // 혹시 Bearer 없이 Authorization에 바로 토큰을 보낸 경우도 지원
                token = authHeader.trim();
            }
        }

        // 커스텀 access 헤더도 지원 (기존 로직 호환)
        if (token == null) {
            String accessHeader = request.getHeader("access");
            if (accessHeader != null) {
                token = accessHeader.startsWith("Bearer ") ? accessHeader.substring(7).trim() : accessHeader.trim();
            }
        }

        // 2) 토큰이 없으면 다음 필터로(→ SecurityConfig 규칙에 따라 401/403 처리)
        if (token == null || token.isEmpty()) {
            filterChain.doFilter(request, response);
            return;
        }

        // 3) 만료/유효성/카테고리(access) 검사
        try {
            jwtUtil.isExpired(token);
        } catch (ExpiredJwtException e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().print("access token expired");
            return;
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().print("invalid access token");
            return;
        }

        String category = jwtUtil.getCategory(token);
        if (!"access".equals(category)) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().print("invalid access token");
            return;
        }

        // 4) 이메일/권한 추출 후 Authentication 세팅
        String email = jwtUtil.getEmail(token);
        String role = jwtUtil.getRole(token); // 예: "ROLE_USER" 또는 "ROLE_ADMIN"

        // 현재 구조에 맞춰 CustomUserDetails 사용(기존 기능 보존)
        LoginUserDTO dto = LoginUserDTO.of(email, role);
        CustomUserDetails customUserDetails = new CustomUserDetails(dto);

        Authentication authToken =
                new UsernamePasswordAuthenticationToken(customUserDetails, null, customUserDetails.getAuthorities());
        SecurityContextHolder.getContext().setAuthentication(authToken);

        // 5) 다음 필터로
        filterChain.doFilter(request, response);
    }
}
