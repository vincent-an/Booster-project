package fortuneCookie.booster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
